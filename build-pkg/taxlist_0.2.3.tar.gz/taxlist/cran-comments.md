## Test environments
* ubuntu (on travis-ci)
* win-builder (devel and release)

## R CMD check results
There were no ERRORs, WARNINGs or NOTEs. 
